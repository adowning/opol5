<template>
    <div>
    <ConfirmSignUp></ConfirmSignUp>
    </div>
</template>

<script>
import ConfirmSignUp from '../../components/amplify/ConfirmSignUp'
export default {
  layout: 'nouser',
  components: {
    ConfirmSignUp
  }
}
</script>
