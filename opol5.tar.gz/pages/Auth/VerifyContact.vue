<template>
    <div>
    <VerifyContact></VerifyContact>
    </div>
</template>

<script>
import VerifyContact from '../../components/amplify/VerifyContact'
export default {
  layout: 'nouser',
  components: {
    VerifyContact
  }
}
</script>
