<template>
    <div>
    <ForgotPassword></ForgotPassword>
    </div>
</template>

<script>
import ForgotPassword from '../../components/amplify/ForgotPassword'
export default {
  layout: 'nouser',
  components: {
    ForgotPassword
  }
}
</script>
